=== AILeash AI Compliance ===
Contributors: monopcontent
Tags: AI compliance, EU AI Act, ai.txt, governance, GDPR, Online Safety Act
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automatically generates your ai.txt governance declaration and connects to the AILeash SHA-256 Merkle audit chain.

== Description ==

AILeash Compliance is the easiest way to declare your AI governance posture and prove compliance with the EU AI Act, UK Online Safety Act, GDPR Article 22, and the Digital Services Act.

= What it does =

* Automatically serves a verified ai.txt file at yourdomain.com/ai.txt
* Connects to the AILeash SHA-256 Merkle audit chain
* Maps your compliance status to EU AI Act Articles 9, 12, 13, 14
* Lists your domain in the Safe AI Registry at sebbi.pro/registry
* Adds a compliance badge shortcode [aileash_badge] for your site

= Why you need this =

The EU AI Act enforcement deadline is August 2026. Article 12 requires tamper-evident audit logs of every AI decision. The UK Online Safety Act is already in force. GDPR Article 22 covers automated decision making.

ai.txt is the open standard for declaring AI compliance at the infrastructure level — like robots.txt, but for AI accountability. This plugin implements it automatically.

= Getting started =

1. Install and activate the plugin
2. Go to Settings > AILeash
3. Add your free API key from sebbi.pro
4. Select your applicable regulations
5. Your verified ai.txt is live at yourdomain.com/ai.txt

== Installation ==

1. Upload the plugin files to /wp-content/plugins/aileash-compliance/
2. Activate the plugin through the Plugins screen in WordPress
3. Go to Settings > AILeash to configure your compliance settings

== Frequently Asked Questions ==

= Is the API key free? =

Yes. Get a free key at sebbi.pro — 100 free decisions included, no card required.

= What is ai.txt? =

ai.txt is an open standard for declaring AI governance compliance at the infrastructure level. Every crawler, every AI system, and every regulator that visits your domain reads it. Specification at sebbi.pro/ai-standard.

= What is the Safe AI Registry? =

A public registry of domains that have published verified ai.txt declarations. Being listed signals to regulators, clients, and partners that your AI is governed. Apply at sebbi.pro/registry.

= What regulations does this cover? =

EU AI Act 2024/1689, UK Online Safety Act 2023, GDPR Article 22, Digital Services Act, ICO Children's Code.

== Changelog ==

= 1.0.0 =
* Initial release
* ai.txt generation and serving
* AILeash chain verification
* Safe AI Registry application
* Compliance badge shortcode

== Upgrade Notice ==

= 1.0.0 =
Initial release.
